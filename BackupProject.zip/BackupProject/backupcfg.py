sourceFile = "/home/ec2-user/environment/BackupProject/test1.txt"
sourceDirectory = "/home/ec2-user/environment/BackupProject/BackupFolderTest/"
destinationDirectory = "/home/ec2-user/environment/BackupProject/Backups/"
