import sys
import os
import pathlib
import shutil
import logging
import smtplib
import backupcfg
from datetime import datetime

logging.basicConfig(filename="/home/ec2-user/environment/BackupProject/backup.log", level = logging.DEBUG) 
logger=logging.getLogger()

# Source File, Source Directory and Destination Directory from config file. 
srcFile = backupcfg.sourceFile
srcDir = backupcfg.sourceDirectory
dstDir = backupcfg.destinationDirectory
    
def copy_file():
    """
    This Python code demonstrates the following features:
        
    * extracting the path component from a full file specification
    * copying a file
    * copying a directory.
        
    """
    
    try:
        dateTimeStamp = datetime.now().strftime("%Y-%m-%d-%H:%M.%S")  
            
        # srcFile = "/home/ec2-user/environment/BackupProject/test1.txt"
        # srcDir = "/home/ec2-user/environment/BackupProject/BackupFolderTest/"
            
        srcLoc = srcFile # change this srcLoc = srcDir to test copying a directory
        srcPath = pathlib.PurePath(srcLoc)
            
        # dstDir = "/home/ec2-user/environment/BackupProject/Backups/"
        dstLoc = dstDir + "/" + srcPath.name + "-" + dateTimeStamp
            
        print("Date time stamp is " + dateTimeStamp) 
        print("Source file is " + srcFile)
        print("Source directory is " + srcDir)
        print("Source location is " + srcLoc)
        print("Destination directory is " + dstDir)
        print("Destination location is " + dstLoc)
            
        if pathlib.Path(srcLoc).is_dir():
            shutil.copytree(srcLoc, dstLoc)
        else:
            shutil.copy2(srcLoc, dstLoc)
        logger.info("SUCCESS: Files copied successfully. ")
    except Exception as err:
        print("ERROR: An error occurred in copy_file.", err)
        logger.error(err, dateTimeStamp)
        # send_email("ERROR: The program has a problem copying a file/directory.")
        
        

apikey = "59444932d58b12b52e768ac50e37be55"
secretkey = "3e2d6eb5a68f7990f65f46f042496231"

smtp = {"sender": "11140931@students.sunitafe.edu.au",    # mailjet.com verified sender
        "recipient": "hwin@sunitafe.edu.au", # mailjet.com verified recipient
        "server": "in-v3.mailjet.com",      # mailjet.com SMTP server
        "port": 587,                           # mailjet.com SMTP port
        "user": apikey,      # mailjet.com user
        "password": secretkey}     # mailjet.com password
        
def send_email(message):
    """
    This Python code demonstrates the following features:
    
    * send an email using the Mailjet.com smtp server if an error occurs.
    """
    

    email = 'To: ' + smtp["recipient"] + '\n' + 'From: ' + smtp["sender"] + '\n' + 'Subject: Backup Error\n\n' + message + '\n'

    # connect to email server and send email
    try:
        smtp_server = smtplib.SMTP(smtp["server"], smtp["port"])
        smtp_server.ehlo()
        smtp_server.starttls()
        smtp_server.ehlo()
        smtp_server.login(smtp["user"], smtp["password"])
        smtp_server.sendmail(smtp["sender"], smtp["recipient"], email)
        smtp_server.close()
        logger.info("Email sent successfully.")
    except Exception as err:
        print("ERROR: The program has a problem sending an email.", err)
        logger.error(err)
            
def main():
    """
    This Python code demonstrates the following features:
    
    * accessing command line arguments.
    * running the program.
    * logging errors if they occur.
    
    """
    try:
        argCount = len(sys.argv)
        program = sys.argv[0]
        arg1 = sys.argv[1]
        # arg2 = sys.argv[2] # if you need more arguments, uncomment this.
        
        if(arg1=="job1"):
            copy_file()
            print("The program name is " + program + ".")
            print("The number of command line items is " + str(argCount) + ".")
            print("Command line argument 1 is " + arg1 + ".")
            #print("Command line argument 2 is " + arg2 + ".")
        else:
            print("Job # is incorrect.")
            logger.error("Job # incorrect. ")
            # send_email("ERROR: The program has a problem with an incorrect Job #.")
        
    except Exception as err:
        print("ERROR: An error occurred.", err)


if __name__ == "__main__":
    main()