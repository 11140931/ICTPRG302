
import sys
# import os
import pathlib
import shutil
import smtplib
import logging
from datetime import datetime
import backupcfg

# errFlag = False
# errMsg = ""

# Attempting to makes sure the config file is found and imported.
# try:
#     import backupcfg
# except ModuleNotFoundError as err:
#     print("Config file not found.", err)
#     errFlag = True
#     errMsg = "Config file not found", err


# Assigns the location of the backup log and the level of the logger.
logFile = backupcfg.loggingFile
logging.basicConfig(filename=logFile, level = logging.DEBUG) 
logger=logging.getLogger()

# if(errFlag): # It is supposed to log an error if the config file is not found. But it doesn't know where to find the backup log because the path is inside the config it can't find...
#     logger.error(errMsg)

# The destination directory of backups.
dstDir = backupcfg.destinationDirectory
    

def copy_file1():
    """
    This Python code demonstrates the following features:
        
    * extracting the path component from a full file specification
    * copying a file
    * copying a directory
    * prints and logs errors found
        
    """
    
    try:
        dateTimeStamp = datetime.now().strftime("%Y-%m-%d-%H:%M.%S")  
            
        srcFile1 = backupcfg.sourceFile1    
        srcDir1 = backupcfg.sourceDirectory1
            
        srcLoc = srcFile1 # Change srcFile1 to srcDir1 or vise versa to test Files or Directories.
        srcPath = pathlib.PurePath(srcLoc)
            
        dstLoc = dstDir + "/" + srcPath.name + "-" + dateTimeStamp
            
        print("Date time stamp is " + dateTimeStamp) 
        print("Source file is " + srcFile1)
        print("Source directory is " + srcDir1)
        print("Source location is " + srcLoc)
        print("Destination directory is " + dstDir)
        print("Destination location is " + dstLoc)
            
        if pathlib.Path(srcLoc).is_dir():
            shutil.copytree(srcLoc, dstLoc)
        else:
            shutil.copy2(srcLoc, dstLoc)
            
        logger.info("SUCCESS: Files copied successfully. ")
        
    except FileNotFoundError as err:
        print("ERROR: File or directory was not found.", err)
        logger.error(err)
        # send_email("ERROR: The program has a problem copying a file/directory.") # Uncomment this to test sending emails after errors.
        
def copy_file2():
    """
    This Python code demonstrates the following features:
        
    * extracting the path component from a full file specification
    * copying a file
    * copying a directory.
    * prints and logs errors found
        
    """
    
    try:
        dateTimeStamp = datetime.now().strftime("%Y-%m-%d-%H:%M.%S")  
            

        srcFile2 = backupcfg.sourceFile2
        srcDir2 = backupcfg.sourceDirectory2
            
        srcLoc = srcFile2 # Change srcFile2 to srcDir2 or vise versa to test Files or Directories.
        srcPath = pathlib.PurePath(srcLoc)
            

        dstLoc = dstDir + "/" + srcPath.name + "-" + dateTimeStamp
            
        print("Date time stamp is " + dateTimeStamp) 
        print("Source file is " + srcFile2)
        print("Source directory is " + srcDir2)
        print("Source location is " + srcLoc)
        print("Destination directory is " + dstDir)
        print("Destination location is " + dstLoc)
            
        if pathlib.Path(srcLoc).is_dir():
            shutil.copytree(srcLoc, dstLoc)
        else:
            shutil.copy2(srcLoc, dstLoc)
            
        logger.info("SUCCESS: Files copied successfully. ")
        
    except FileNotFoundError as err:
        print("ERROR: File or directory was not found.", err)
        logger.error(err)
        # send_email("ERROR: The program has a problem copying a file/directory.") #uncomment this to test sending emails after errors.

def copy_file3():
    """
    This Python code demonstrates the following features:
        
    * extracting the path component from a full file specification
    * copying a file
    * copying a directory
    * prints and logs errors found
        
    """
    
    try:
        dateTimeStamp = datetime.now().strftime("%Y-%m-%d-%H:%M.%S")  
            
        srcFile3 = backupcfg.sourceFile3  
        srcDir3 = backupcfg.sourceDirectory3
            
        srcLoc = srcFile3 # Change srcFile3 to srcDir3 or vise versa to test Files or Directories.
        srcPath = pathlib.PurePath(srcLoc)
            
        dstLoc = dstDir + "/" + srcPath.name + "-" + dateTimeStamp
            
        print("Date time stamp is " + dateTimeStamp) 
        print("Source file is " + srcFile3)
        print("Source directory is " + srcDir3)
        print("Source location is " + srcLoc)
        print("Destination directory is " + dstDir)
        print("Destination location is " + dstLoc)
            
        if pathlib.Path(srcLoc).is_dir():
            shutil.copytree(srcLoc, dstLoc)
        else:
            shutil.copy2(srcLoc, dstLoc)
            
        logger.info("SUCCESS: Files copied successfully. ")
        
    except FileNotFoundError as err:
        print("ERROR: File or directory was not found.", err)
        logger.error(err)
        # send_email("ERROR: The program has a problem copying a file/directory.") # Uncomment this to test sending emails after errors.
        
apikey = "" # mailjet username
secretkey = "" # mailjet password

smtp = {"sender": "11140931@students.sunitafe.edu.au",    # mailjet.com verified sender
        "recipient": "hwin@sunitafe.edu.au", # mailjet.com verified recipient
        "server": "in-v3.mailjet.com",      # mailjet.com SMTP server
        "port": 587,                           # mailjet.com SMTP port
        "user": apikey,      # mailjet.com user
        "password": secretkey}     # mailjet.com password
        
def send_email(message):
    """
    This Python code demonstrates the following features:
    
    * send an email using the Mailjet.com smtp server if an error occurs.
    * log an error if email did not send.
    """
    

    email = 'To: ' + smtp["recipient"] + '\n' + 'From: ' + smtp["sender"] + '\n' + 'Subject: Backup Error\n\n' + message + '\n'

    # Connect to email server and send emails.
    try:
        smtp_server = smtplib.SMTP(smtp["server"], smtp["port"])
        smtp_server.ehlo()
        smtp_server.starttls()
        smtp_server.ehlo()
        smtp_server.login(smtp["user"], smtp["password"])
        smtp_server.sendmail(smtp["sender"], smtp["recipient"], email)
        smtp_server.close()
        logger.info("Email sent successfully.")
        
    except Exception as err:
        print("ERROR: The program has a problem sending an email.", err)
        logger.error(err)
            
            
def main():
    """
    This Python code demonstrates the following features:
    
    * accessing command line arguments
    * logging errors if they occur
    
    """
    
    try:
        argCount = len(sys.argv)
        program = sys.argv[0]
        arg1 = sys.argv[1]
        # arg2 = sys.argv[2] # this sets the minimum arguments in the command line.
        # arg3 = sys.argv[3]
        
        if(arg1=="job1"):
            copy_file1()
            print("The program name is " + program + ".")
            print("The number of command line items is " + str(argCount) + ".")
            print("Command line argument 1 is " + arg1 + ".")
            # print("Command line argument 2 is " + arg2 + ".")
            # print("Command like arugment 3 is " + arg3 + ".")
            
        elif(arg1=="job2"):
            copy_file2()
            print("The program name is " + program + ".")
            print("The number of command line items is " + str(argCount) + ".")
            print("Command line argument 1 is " + arg1 + ".")
            # print("Command line argument 2 is " + arg2 + ".")
            # print("Command like arugment 3 is " + arg3 + ".")
            
        elif(arg1=="job3"):
            copy_file3()
            print("The program name is " + program + ".")
            print("The number of command line items is " + str(argCount) + ".")
            print("Command line argument 1 is " + arg1 + ".")
            # print("Command line argument 2 is " + arg2 + ".")
            # print("Command like arugment 3 is " + arg3 + ".")
            
            
        else:
            print("Job # is incorrect.")
            logger.error("Job # incorrect. ")
            # send_email("ERROR: The program has a problem with an incorrect Job #.") #uncomment this to test sending emails after errors.
        
    except Exception as err:
        print("ERROR: An error occurred.", err)
        logger.error(err)
        # send_email("ERROR: The program has a problem with an incorrect Job #.") #uncomment this to test sending emails after errors.


if __name__ == "__main__":
    main()